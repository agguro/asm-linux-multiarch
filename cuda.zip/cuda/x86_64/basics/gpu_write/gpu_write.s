# -----------------------------------------------------------------------------
# File: main.s
# Description: 
#   A complete CUDA Driver API host application in x86_64 Assembly.
#   Tests: Get the original number (42.0), overwrite it from the host, 
#   retrieve it, and print the newly overwritten number.
# -----------------------------------------------------------------------------

.nolist
    .include "unistd.inc"
.list

# --- Read-Only Data Section ---
.section .rodata
    .align 8
    kernel_bin:  .incbin "gpu_write.cubin"
    kernel_name: .asciz  "gpu_write"
    
    # Printing templates
    fmt_orig:    .asciz  "Original Value at d_c[0]: %.1f\n"
    fmt_new:     .asciz  "Overwritten Value at d_c[0]: %.2f\n"

# --- Data Section ---
.section .data
    .align 8
    h_module:      .quad   0
    h_func:        .quad   0
    d_c:           .quad   0
    
    # Kernel Argument Array placeholders
    param_a:       .quad   0 
    param_b:       .quad   0 
    param_c:       .quad   0 
    param_n:       .quad   0
    
    .align 8
    kernel_params: .quad param_a, param_b, param_c, param_n
    
    # Host buffers for data exchange
    h_c:           .float  0.0
    h_new_val:     .float  123.45  # The number we will use to overwrite the GPU

# --- Executable Code Section ---
.section .text
.globl _start
.type _start, @function

_start:
    # --- 1. Robust ABI Stack Alignment ---
    pushq   %rbp
    movq    %rsp, %rbp
    andq    $-16, %rsp      # 16-byte alignment
    subq    $512, %rsp      # Local scratch space

    # --- 2. Initialize CUDA Driver ---
    xorl    %edi, %edi      
    call    cuInit@PLT

    leaq    16(%rsp), %rdi  # &device
    xorl    %esi, %esi      # device 0
    call    cuDeviceGet@PLT

    leaq    24(%rsp), %rdi  # &context
    xorl    %esi, %esi      
    movl    16(%rsp), %edx  
    call    cuCtxCreate_v2@PLT

    # --- 3. Load Kernel Module and Function ---
    leaq    h_module(%rip), %rdi
    leaq    kernel_bin(%rip), %rsi
    call    cuModuleLoadData@PLT

    leaq    h_func(%rip), %rdi
    movq    h_module(%rip), %rsi
    leaq    kernel_name(%rip), %rdx
    call    cuModuleGetFunction@PLT

    # --- 4. GPU Memory Allocation ---
    movq    $4096, %rsi     # 4KB buffer
    leaq    d_c(%rip), %rdi
    call    cuMemAlloc_v2@PLT

    # --- 5. Initial Argument Mapping ---
    movq    d_c(%rip), %rax
    movq    %rax, param_a(%rip) 
    movq    %rax, param_b(%rip) 
    movq    %rax, param_c(%rip) 
    movq    $1, param_n(%rip)

    # --- 6. First Launch: GPU writes its original 42.0 ---
    subq    $80, %rsp
    movq    $1, 0(%rsp)              
    movq    $0, 8(%rsp)              
    movq    $0, 16(%rsp)             
    leaq    kernel_params(%rip), %rax
    movq    %rax, 24(%rsp)           
    movq    $0, 32(%rsp)             

    movq    h_func(%rip), %rdi       
    movl    $1, %esi; movl $1, %edx; movl $1, %ecx  
    movl    $1, %r8d; movl $1, %r9d;               
    call    cuLaunchKernel@PLT
    addq    $80, %rsp

    call    cuCtxSynchronize@PLT

    # --- 7. Read Back Original 42.0 From GPU ---
    leaq    h_c(%rip), %rdi          
    movq    d_c(%rip), %rsi          
    movq    $4, %rdx                 # 4 bytes for float
    call    cuMemcpyDtoH_v2@PLT

    # --- 8. Print Original Value ---
    leaq    fmt_orig(%rip), %rdi
    pxor    %xmm0, %xmm0             
    cvtss2sd h_c(%rip), %xmm0        
    movb    $1, %al                  
    call    printf@PLT

    # --- 9. Overwrite the Value Directly on the GPU ---
    # We take our host float (123.45) and push it directly into the GPU memory buffer
    movq    d_c(%rip), %rdi          # Destination: GPU Pointer
    leaq    h_new_val(%rip), %rsi    # Source: Host memory containing 123.45
    movq    $4, %rdx                 # Size: 4 bytes
    call    cuMemcpyHtoD_v2@PLT
    
    call    cuCtxSynchronize@PLT

    # --- 10. Read Back the Overwritten Value From the GPU ---
    # To prove it changed, clear the local host buffer h_c first
    movl    $0, h_c(%rip)

    leaq    h_c(%rip), %rdi          
    movq    d_c(%rip), %rsi          
    movq    $4, %rdx                 
    call    cuMemcpyDtoH_v2@PLT

    # --- 11. Print Overwritten Value ---
    leaq    fmt_new(%rip), %rdi
    pxor    %xmm0, %xmm0             
    cvtss2sd h_c(%rip), %xmm0        
    movb    $1, %al                  
    call    printf@PLT

    # --- 12. Clean Exit ---
    xorq    %rdi, %rdi
    movq    $exit_group, %rax        
    syscall

# Symbol size calculation
.size _start, . - _start

# --- Metadata ---
.section .note.GNU-stack,"",@progbits
